# Mesa Fiscal VPS 2.0

Backend independente para Ubuntu/Docker, com painel web em português. Usa NFePHP 5.2.8 para abrir o certificado A1, assinar XML e comunicar-se com a SEFAZ. Dependências fixadas em composer.lock.

## O que está implementado

- Login administrativo, token separado para API e proteção contra CSRF.
- Cadastro de CNPJ, razão social, IE, UF, ambiente, CSC e ID do CSC.
- Upload de A1 .pfx/.p12 (até 256 KB), validação de senha, CNPJ e datas de validade.
- Configuração e certificado criptografados com AES-256-GCM; segredos não voltam ao navegador.
- Consulta de disponibilidade da SEFAZ e consulta por chave.
- Assinatura e transmissão de XML NFC-e modelo 65 previamente preparado, retorno fiscal, XML autorizado e consulta para reconciliar respostas incertas.
- Documentos separados por ambiente e CNPJ; repetição da mesma chave não provoca reenvio automático.
- Conexão pelo site Mesa: URL e token; transferência do certificado e cadastro do site para esta VPS.

## Limite importante

Este pacote é um backend de configuração, consulta e transmissão de XML. **Ainda não transforma os pedidos do PDV em notas**, não calcula impostos, não decide NCM/CFOP/CSOSN/CST/IBS/CBS, não controla a próxima numeração do PDV, não gera DANFE e não implementa cancelamento ou inutilização. O XML deve vir de um gerador fiscal que preencha essas regras e controle série/numeração. Nenhuma nota real foi emitida nos testes deste pacote. Não trate a disponibilidade da SEFAZ (cStat 107) como validação do CSC ou credenciamento.

## 1. Instalar na VPS

Pré-requisitos: Docker Engine com plugin Compose e Python 3. Instruções oficiais para Ubuntu: https://docs.docker.com/engine/install/ubuntu/ . O instalador não altera Docker, firewall, DNS nem outros sites existentes.

Envie o ZIP para a VPS com SFTP/SCP e execute na pasta que recebeu o arquivo:

```bash
sudo mkdir -p /opt/mesa-fiscal
sudo unzip Mesa-Fiscal-VPS.zip -d /opt/mesa-fiscal
cd /opt/mesa-fiscal/Mesa-Fiscal-VPS
sudo bash configurar.sh
```

O script cria segredos exclusivos e inicia o backend. Reexecutar preserva segredos e dados existentes. A porta 9080 fica vinculada somente a 127.0.0.1.

Veja a senha do painel no seu terminal particular:

```bash
sudo cat secrets/admin_password
```

Não envie esse conteúdo em conversa nem em captura de tela. O token usado pelo PDV é outro:

```bash
sudo cat secrets/api_token
```

## 2. Abrir com segurança

### Opção A: acesso inicial por SSH

No seu computador, mantenha este comando aberto (troque USUARIO e IP_DA_VPS):

```bash
ssh -L 9080:127.0.0.1:9080 USUARIO@IP_DA_VPS
```

Acesse `http://127.0.0.1:9080` no navegador do computador. Esse tráfego passa pelo túnel SSH. No celular, use um cliente SSH com encaminhamento de porta ou configure o domínio HTTPS abaixo.

### Opção B: domínio HTTPS, VPS sem outro serviço nas portas 80/443

1. Crie um registro DNS A para `fiscal.seudominio.com` apontando para o IP público da VPS. Se houver registro AAAA, ele também precisa estar correto.
2. Permita entrada TCP 80 e 443 no firewall da VPS/provedor.
3. Edite `.env` nesta pasta:

```dotenv
COOKIE_SECURE=1
FISCAL_DOMAIN=fiscal.seudominio.com
```

4. Inicie com o arquivo adicional:

```bash
sudo docker compose -f compose.yaml -f compose.https.yaml up -d --build
```

5. Abra `https://fiscal.seudominio.com`. O Caddy solicita o certificado HTTPS. Os comandos futuros de reinício/atualização devem usar os mesmos dois arquivos.

### Se a VPS já tem HestiaCP, Nginx ou Apache

Não use o Caddy nas portas já ocupadas. Mantenha `compose.yaml`, crie um domínio HTTPS no painel existente e configure o proxy para `http://127.0.0.1:9080`. Há um exemplo de bloco Nginx em `nginx-https.conf.example`. No Hestia, use configuração/template persistente próprio; não sobrescreva os outros sites. Defina `COOKIE_SECURE=1` em `.env` e execute `sudo docker compose up -d`.

## 3. Configurar no próprio backend

Entre com a senha administrativa, preencha dados, selecione **Produção** se o CSC pertence a produção, envie o A1 e informe a senha. Marque habilitação de produção somente quando quiser permitir o envio de documentos reais. Salvar não emite nenhuma nota.

O certificado precisa estar em um formato PKCS#12 aceito pelo OpenSSL atual. Se o arquivo usar cifras antigas e não abrir, reexporte-o em formato atual a partir do gerenciador de certificados; não desative verificações TLS.

Use **Testar conexão / disponibilidade**. O retorno vem da SEFAZ. Para transmitir uma nota real, o painel exige confirmação explícita, e a API exige `X-Confirm-Production: YES` além da habilitação no cadastro.

## 4. Conectar ao PDV Mesa

No site https://mesa-pdv-restaurante.guilnhermedesouzafer.chatgpt.site abra **Integrações → Conectar minha VPS**:

1. Informe a URL HTTPS, sem caminho, e o conteúdo de `secrets/api_token` no campo Token.
2. Clique **Verificar e salvar conexão**. O PDV confere `/health` com o token.
3. Se o certificado e o CSC já estão salvos no site, preencha a razão social e clique **Enviar certificado e cadastro à VPS**. O destino recebe esses dados por HTTPS. O cadastro atual da VPS será substituído pelos dados do site; confira o ambiente selecionado no cadastro do site.
4. O backend abre o A1, confere senha/CNPJ/validade e só então salva.
5. Use **Consultar disponibilidade da SEFAZ** no PDV.

O envio do cadastro não ativa a emissão automática dos pedidos. A interface informa essa limitação. Você pode consultar pelo site e transmitir XML preparado pelo painel do backend.

## API

Autenticação: `Authorization: Bearer TOKEN_DA_API`. Token nunca em query string. Não exponha a API por HTTP público. CORS não é necessário: o site acessa o backend pelo seu servidor.

| Método e rota | Função |
| --- | --- |
| GET /health | Saúde autenticada do backend, sem consultar SEFAZ |
| GET /config | Cadastro sem CSC, senha nem certificado |
| POST /config | Multipart: cnpj, razaosocial, ie, siglaUF, tpAmb (1/2), CSCid, CSC, password, certificate, revision, productionEnabled (YES ou vazio) |
| GET /status | Disponibilidade da SEFAZ no ambiente cadastrado |
| POST /consultar | JSON `{"chave":"44 dígitos"}`; pode recuperar protocolo e completar XML local |
| POST /autorizar | Corpo XML modelo 65 sem assinatura, até 1 MB; assina e envia |
| GET /xml?chave=… | Download do XML autorizado arquivado |

`revision` vem de GET /config; em cadastro novo use 0. Em edição, CSC/senha vazios mantêm os valores anteriores. Novo arquivo exige senha. Mudança de CNPJ ou ambiente exige informar o CSC correspondente. O endereço da VPS deve ser dedicado à raiz do backend, sem subpasta.

### Exemplo de consulta no terminal da VPS

Sem colocar o token no histórico/comando de processo:

```bash
sudo sh -c '{ printf "Authorization: Bearer "; cat secrets/api_token; } | curl --fail-with-body --header @- http://127.0.0.1:9080/status'
```

### Respostas fiscais

Leia `sefaz.cStat` e `sefaz.xMotivo`. HTTP 200 indica que a requisição foi processada; sozinho não indica autorização fiscal. O backend arquiva autorização quando o retorno traz cStat 100/150. `uncertain` exige consulta da chave antes de qualquer nova tentativa. Depois de uma rejeição, este pacote não reenvia a mesma chave automaticamente; correção/reenvio deve ser implementada no fluxo emissor antes do uso contínuo em produção.

## Armazenamento e operação

- `data/profile.enc`: cadastro e A1 criptografados.
- `data/documents/AMBIENTE/CNPJ/`: banco, XML assinado, retorno e XML autorizado. Os XML não são criptografados pelo aplicativo; proteja disco e backups.
- `secrets/encryption_key`: chave necessária para abrir o cadastro.
- `secrets/api_token` e `secrets/admin_password`: credenciais diferentes.

Faça backup protegido de `data/` e `secrets/` juntos; perder a chave impede recuperar o cadastro. Não coloque essas pastas em diretório público nem em Git. Para copiar o banco de maneira consistente, pare o serviço durante a cópia ou use backup SQLite adequado.

```bash
sudo docker compose logs --tail=100 fiscal
sudo docker compose ps
```

Com o modo HTTPS/Caddy, acrescente `-f compose.yaml -f compose.https.yaml` aos comandos.

## Verificação realizada

PHP 8.3: sintaxe; instalação de dependências reais via Composer; teste HTTP local com certificado sintético incluindo autenticação, senha inválida, CNPJ divergente, salvamento, proteção de segredos, revisão concorrente, bloqueio de envio real quando desabilitado, preservação de credenciais e detecção de adulteração do cadastro. Testes nunca chamam SEFAZ.

O build Docker e a execução na sua VPS não foram realizados neste ambiente. Conexão real, aceitação fiscal, regras tributárias e autorização de NFC-e só podem ser verificadas com sua instalação e dados reais.

Para repetir testes sem SEFAZ após instalar dependências:

```bash
python3 tests/test_backend.py
```

Fontes técnicas: https://github.com/nfephp-org/sped-nfe e https://github.com/nfephp-org/sped-common . O código do aplicativo é entregue no ZIP; bibliotecas mantêm suas licenças próprias.
