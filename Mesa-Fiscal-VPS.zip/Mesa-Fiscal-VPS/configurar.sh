#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ "$(id -u)" -ne 0 ]; then echo 'Execute: sudo bash configurar.sh'; exit 1; fi
command -v docker >/dev/null || { echo 'Instale Docker Engine com o plugin Compose antes de continuar: https://docs.docker.com/engine/install/ubuntu/'; exit 1; }
docker compose version >/dev/null
command -v python3 >/dev/null
python3 - <<'PY'
from pathlib import Path
import os,secrets
p=Path('secrets');p.mkdir(mode=0o700,exist_ok=True)
for name in ['api_token','admin_password','encryption_key']:
 f=p/name
 if not f.exists():
  with f.open('x') as out: out.write(secrets.token_hex(32)+'\n')
 os.chmod(f,0o400);os.chown(f,33,33)
os.chown(p,33,33);os.chmod(p,0o700)
p=Path('data');p.mkdir(mode=0o700,exist_ok=True);os.chown(p,33,33);os.chmod(p,0o700)
if not Path('.env').exists():Path('.env').write_text('COOKIE_SECURE=0\n')
os.chmod('.env',0o600)
PY
docker compose up -d --build
echo 'Backend disponível na própria VPS: http://127.0.0.1:9080'
echo 'Acesse por túnel SSH ou configure HTTPS conforme o LEIA-ME.md.'
echo 'Senha do painel: sudo cat secrets/admin_password'
echo 'Token para integrar o site: sudo cat secrets/api_token'
echo 'Segredos existentes foram preservados. Faça backup de data/ e secrets/.'
