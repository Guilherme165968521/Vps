"""Testes locais com certificado sintético; nunca contata a SEFAZ."""
import json,os,subprocess,tempfile,time,urllib.request,urllib.error,pathlib,secrets,sys,socket,re,http.cookiejar
root=pathlib.Path(__file__).resolve().parents[1];php=os.environ.get('PHP_BIN','php')
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp);(p/'data').mkdir();(p/'secrets').mkdir()
 for n in ['api_token','admin_password','encryption_key']:(p/'secrets'/n).write_text(secrets.token_hex(32))
 cfg=p/'cert.cnf';cfg.write_text('[req]\ndistinguished_name=dn\nx509_extensions=ext\nprompt=no\n[dn]\nCN=TESTE LOCAL\n[ext]\nsubjectAltName=otherName:2.16.76.1.3.3;UTF8:11222333000181\n')
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(p/'key.pem'),'-out',str(p/'cert.pem'),'-days','1','-config',str(cfg)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run(['openssl','pkcs12','-export','-out',str(p/'test.pfx'),'-inkey',str(p/'key.pem'),'-in',str(p/'cert.pem'),'-passout','pass:only-test'],check=True)
 sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
 env={**os.environ,'SECRETS_DIR':str(p/'secrets'),'DATA_DIR':str(p/'data')}
 with (p/'log').open('w') as log:
  server=subprocess.Popen([php,'-S',f'127.0.0.1:{port}',str(root/'router.php')],cwd=root,env=env,stdout=log,stderr=log)
  try:
   base=f'http://127.0.0.1:{port}';token=(p/'secrets/api_token').read_text()
   def req(path,body=None,headers=None,auth=True):
    h={'Authorization':'Bearer '+token} if auth else {};h.update(headers or {})
    try:r=urllib.request.urlopen(urllib.request.Request(base+path,data=body,headers=h),timeout=3)
    except urllib.error.HTTPError as e:r=e
    return r.status,r.read()
   for i in range(50):
    try:req('/health');break
    except OSError:time.sleep(.1)
   assert req('/health',auth=False)[0]==401
   assert json.loads(req('/health')[1])['configured'] is False
   fields={'cnpj':'11222333000181','ie':'12345678','razaosocial':'TESTE LOCAL','siglaUF':'MT','tpAmb':'1','CSCid':'1','CSC':'csc-synthetic-only','password':'only-test','revision':'0'}
   def multipart(fields,cert=True):
    boundary='mesa-test-'+secrets.token_hex(8);parts=[]
    for k,v in fields.items():parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    if cert:parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="certificate"; filename="test.pfx"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+(p/'test.pfx').read_bytes()+b'\r\n')
    parts.append(f'--{boundary}--\r\n'.encode());return b''.join(parts),{'Content-Type':f'multipart/form-data; boundary={boundary}'}
   body,h=multipart({**fields,'password':'wrong'});assert req('/config',body,h)[0]==400
   body,h=multipart({**fields,'cnpj':'04252011000110'});assert req('/config',body,h)[0]==400
   body,h=multipart(fields);status,data=req('/config',body,h);assert status==200,(status,data)
   out=json.loads(data);assert out['revision']==1 and out['tpAmb']==1
   assert b'csc-synthetic-only' not in data and b'only-test' not in data and b'pfx"' not in data.replace(b'test.pfx"',b'')
   assert b'csc-synthetic-only' not in (p/'data/profile.enc').read_bytes()
   assert req('/config',body,h)[0]==409
   status,data=req('/autorizar',b'<NFe/>',{'Content-Type':'application/xml','X-Confirm-Production':'YES'});assert status==403,(status,data)
   status,data=req('/config');assert status==200
   # Mantém segredos sem arquivo novo.
   body,h=multipart({**fields,'revision':'1','CSC':'','password':''},False);assert req('/config',body,h)[0]==200
   # Falha fechada se o conteúdo criptografado for alterado.
   content=bytearray((p/'data/profile.enc').read_bytes());content[-1]^=1;(p/'data/profile.enc').write_bytes(content)
   assert req('/config')[0]==503
   print('PASS: autenticação, cadastro A1, senha incorreta, CNPJ divergente, sigilo, criptografia, concorrência, bloqueio de produção, preservação e adulteração.')
  finally:server.terminate();server.wait(timeout=5)
