<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');header('Referrer-Policy: no-referrer');header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'");
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);$method=$_SERVER['REQUEST_METHOD'];
if(in_array($path,['/panel.js','/panel.css'],true)){header('Content-Type: '.($path==='/panel.js'?'text/javascript':'text/css'));readfile(__DIR__.$path);exit;}
ini_set('session.use_strict_mode','1');ini_set('session.save_path',dataDir());session_name('mesa_fiscal');session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>getenv('COOKIE_SECURE')==='1','path'=>'/']);session_start();$_SESSION['csrf']??=bin2hex(random_bytes(24));
if($path==='/'&&$method==='GET'){require __DIR__.'/panel.php';exit;}
try {
 if($path==='/login'&&$method==='POST'){
  if(!hash_equals($_SESSION['csrf'],(string)($_POST['csrf']??'')))send(['error'=>'Sessão expirada. Atualize a página.'],403);
  // Limite global persiste entre sessões para conter tentativas repetidas.
  $limit=fopen(dataDir().'/login-limit','c+');flock($limit,LOCK_EX);$entry=json_decode(stream_get_contents($limit),true)?:['start'=>time(),'count'=>0];if(time()-$entry['start']>60)$entry=['start'=>time(),'count'=>0];if($entry['count']>=10){flock($limit,LOCK_UN);send(['error'=>'Aguarde um minuto antes de tentar novamente.'],429);}$entry['count']++;ftruncate($limit,0);rewind($limit);fwrite($limit,json_encode($entry));flock($limit,LOCK_UN);fclose($limit);
  if(!hash_equals(secret('admin_password'),(string)($_POST['password']??'')))send(['error'=>'Senha incorreta.'],401);
  session_regenerate_id(true);$_SESSION['admin']=true;$_SESSION['last']=time();send(['ok'=>true]);
 }
 $token=preg_replace('/^Bearer /','',$_SERVER['HTTP_AUTHORIZATION']??'');$api=$token!==''&&hash_equals(secret('api_token'),$token);
 $admin=!empty($_SESSION['admin'])&&time()-($_SESSION['last']??0)<1800;
 if(!$api&&!$admin)send(['error'=>'Não autorizado. Entre no painel ou use Bearer token.'],401);
 if(!$api){$_SESSION['last']=time();if($method!=='GET'&&!hash_equals($_SESSION['csrf'],(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))send(['error'=>'Sessão inválida. Atualize a página.'],403);}
 session_write_close();
 if($path==='/logout'&&$method==='POST'){session_start();$_SESSION=[];session_destroy();send(['ok'=>true]);}
 if($path==='/config'&&$method==='GET')send(publicProfile(profile()));
 if($path==='/config'&&$method==='POST'){
  $lock=fopen(dataDir().'/config.lock','c');flock($lock,LOCK_EX);$old=profile();if((int)($_POST['revision']??0)!==($old['revision']??0))send(['error'=>'Cadastro alterado em outra sessão. Atualize a página.'],409);
  $pfx=null;$in=$_POST;if(isset($_FILES['certificate'])&&$_FILES['certificate']['error']!==UPLOAD_ERR_NO_FILE){$f=$_FILES['certificate'];if($f['error']!==UPLOAD_ERR_OK||$f['size']>262144||!preg_match('/\.(pfx|p12)$/i',$f['name']))send(['error'=>'Envie um A1 .pfx ou .p12 até 256 KB.'],400);$pfx=file_get_contents($f['tmp_name']);$in['filename']=$f['name'];}
  $p=cleanConfig($in,$old,$pfx);atomic(dataDir().'/profile.enc',encryptProfile($p));flock($lock,LOCK_UN);fclose($lock);send(publicProfile($p));
 }
 if($path==='/health'&&$method==='GET')send(['service'=>'Mesa Fiscal VPS','version'=>'2.0','configured'=>is_file(dataDir().'/profile.enc'),'orderToInvoice'=>false]);
 require __DIR__.'/api.php';
}catch(InvalidArgumentException $e){send(['error'=>$e->getMessage()],400);}catch(Throwable $e){error_log('Fiscal: '.get_class($e));send(['error'=>'Operação não concluída. Confira a configuração e os registros do servidor.'],503);}
